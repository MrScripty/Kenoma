Kenoma independent material-response review, source baf27f620effbdf9df16d5b5b32b8c401f1a3db8.
Run python3 -m http.server in this extracted directory, then open http://localhost:8000/index.html to use the ES-module controls.
Numerical computation and static assets are local. External source/neighboring-chapter links require the Internet.
Read material-response.pdf or material-response.md without running the controls. Five narrow Std contracts were compiled freshly; the complete book release is not qualified by this preview.
